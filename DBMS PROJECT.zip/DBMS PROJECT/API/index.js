const express = require('express');
const app = express();
const { Pool } = require('pg');

app.use(express.json());

const pool = new Pool({
  user: 'your_user',
  host: 'your_host',
  database: 'your_database',
  password: 'your_password',
  port: 5432, // default PostgreSQL port
});


app.listen(3000, () => {
  console.log('Server is running on port 3000');
})
app.get('/departments', async (req, res) => {
  const result = await pool.query('SELECT * FROM departments');
  res.json(result.rows);
});

app.get('/jobs', async (req, res) => {
  const result = await pool.query('SELECT * FROM jobs');
  res.json(result.rows);
});

app.get('/employees', async (req, res) => {
  const result = await pool.query('SELECT * FROM employees');
  res.json(result.rows);
});

app.get('/attendance', async (req, res) => {
  const result = await pool.query('SELECT * FROM attendance');
  res.json(result.rows);
});

app.get('/leaves', async (req, res) => {
  const result = await pool.query('SELECT * FROM leaves');
  res.json(result.rows);
});

app.get('/salaries', async (req, res) => {
  const result = await pool.query('SELECT * FROM salaries');
  res.json(result.rows);
});

app.get('/projects', async (req, res) => {
  const result = await pool.query('SELECT * FROM projects');
  res.json(result.rows);
});

app.get('/employee_projects', async (req, res) => {
  const result = await pool.query('SELECT * FROM employee_projects');
  res.json(result.rows);
});

app.get('/users', async (req, res) => {
  const result = await pool.query('SELECT * FROM users');
  res.json(result.rows);
});

app.get('/reviews', async (req, res) => {
  const result = await pool.query('SELECT * FROM reviews');
  res.json(result.rows);
});

app.post('/departments', async (req, res) => {
  const { name } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO departments (name) VALUES ($1) RETURNING *',
      [name]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/jobs', async (req, res) => {
  const { id, title, min_salary, max_salary } = req.body;
  const result = await pool.query(
    'INSERT INTO jobs (id, title, min_salary, max_salary) VALUES ($1, $2, $3, $4) RETURNING *',
    [id, title, min_salary, max_salary]
  );
  res.json(result.rows[0]);
});


app.post('/employees', async (req, res) => {
  const { id, name, email, phone, department_id, job_title } = req.body;
  const result = await pool.query(
    'INSERT INTO employees (id, name, email, phone, department_id, job_title) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
    [id, name, email, phone, department_id, job_title]
  );
  res.json(result.rows[0]);
});


app.post('/attendance', async (req, res) => {
  const { id, employee_id, date, check_in, check_out } = req.body;
  const result = await pool.query(
    'INSERT INTO attendance (id, employee_id, date, check_in, check_out) VALUES ($1, $2, $3, $4, $5) RETURNING *',
    [id, employee_id, date, check_in, check_out]
  );
  res.json(result.rows[0]);
});


app.post('/leaves', async (req, res) => {
  const { id, employee_id, start_date, end_date, reason, status } = req.body;
  const result = await pool.query(
    'INSERT INTO leaves (id, employee_id, start_date, end_date, reason, status) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
    [id, employee_id, start_date, end_date, reason, status]
  );
  res.json(result.rows[0]);
});

app.post('/salaries', async (req, res) => {
  const { id, employee_id, amount, pay_date } = req.body;
  const result = await pool.query(
    'INSERT INTO salaries (id, employee_id, amount, pay_date) VALUES ($1, $2, $3, $4) RETURNING *',
    [id, employee_id, amount, pay_date]
  );
  res.json(result.rows[0]);
});


app.post('/projects', async (req, res) => {
  const { id, name, description } = req.body;
  const result = await pool.query(
    'INSERT INTO projects (id, name, description) VALUES ($1, $2, $3) RETURNING *',
    [id, name, description]
  );
  res.json(result.rows[0]);
});


app.post('/employee_projects', async (req, res) => {
  const { id, employee_id, project_id } = req.body;
  const result = await pool.query(
    'INSERT INTO employee_projects (id, employee_id, project_id) VALUES ($1, $2, $3) RETURNING *',
    [id, employee_id, project_id]
  );
  res.json(result.rows[0]);
});


app.post('/users', async (req, res) => {
  const { id, employee_id, username, password } = req.body;
  const result = await pool.query(
    'INSERT INTO users (id, employee_id, username, password) VALUES ($1, $2, $3, $4) RETURNING *',
    [id, employee_id, username, password]
  );
  res.json(result.rows[0]);
});


app.post('/reviews', async (req, res) => {
  const { id, employee_id, review_date, rating, comments } = req.body;
  const result = await pool.query(
    'INSERT INTO reviews (id, employee_id, review_date, rating, comments) VALUES ($1, $2, $3, $4, $5) RETURNING *',
    [id, employee_id, review_date, rating, comments]
  );
  res.json(result.rows[0]);
});